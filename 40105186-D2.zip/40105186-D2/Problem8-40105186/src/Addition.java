/**
 * 
 * @author Neha
 * Domain Model - PlusOperator
 */
public class Addition implements Operator{

	public double execute(double num1, double num2) {
		return num1+num2;
	}

}
