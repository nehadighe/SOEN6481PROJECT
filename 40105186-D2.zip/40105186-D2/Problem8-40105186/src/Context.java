
public class Context {
Operator operator;

public void setOperator(String operator) {
	if(operator=="+") {
		Addition a=new Addition();
		this.operator=a;
	}
	else if(operator=="-") {
		Subtraction a=new Subtraction();
		this.operator=a;
	}
	else if(operator=="*") {
		Multiplication a=new Multiplication();
		this.operator=a;
	}
	else if(operator=="/") {
		Division a=new Division();
		this.operator=a;
	}
}
public double executeStrategy(double num1, double num2) {
	return this.operator.execute(num1, num2);
}
}
