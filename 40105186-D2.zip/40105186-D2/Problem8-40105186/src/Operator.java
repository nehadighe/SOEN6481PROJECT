/**
 * 
 * @author Neha
 * Domain Model - Operator
 */
public interface Operator {

	public double execute(double num1,double num2);
}
