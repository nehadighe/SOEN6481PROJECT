/**
 * 
 * @author Neha
 * Division Operator
 */
public class Division implements Operator{

	@Override
	public double execute(double num1, double num2) {
		// TODO Auto-generated method stub
		return num1/num2;
	}

}
