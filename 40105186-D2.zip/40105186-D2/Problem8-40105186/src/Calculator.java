/**
 * 
 * @author Neha
 * Controller for the operations
 * Domain Model Calculator
 */
public class Calculator {

	public double ComputeExpression(String input) {
		double output=0.0;
		Context c=new Context();
		if(input.indexOf("+")!=-1) {
			c.setOperator("+");
			String[] line=input.split("\\+");
			output=c.executeStrategy(Double.parseDouble(line[0]), Double.parseDouble(line[1]));
			
		}
		else if(input.indexOf("-")!=-1) {
			c.setOperator("-");
			String[] line=input.split("\\-");
			output=c.executeStrategy(Double.parseDouble(line[0]), Double.parseDouble(line[1]));
		}
		else if(input.indexOf("*")!=-1) {
			c.setOperator("*");
			String[] line=input.split("\\*");
			output=c.executeStrategy(Double.parseDouble(line[0]), Double.parseDouble(line[1]));
		}
		else if(input.indexOf("/")!=-1) {
			c.setOperator("/");
			String[] line=input.split("\\/");
			output=c.executeStrategy(Double.parseDouble(line[0]), Double.parseDouble(line[1]));
		}
		return output;
	}
}
