/**
 * 
 * @author Neha
 * Multiplication operator
 */
public class Multiplication implements Operator{

	@Override
	public double execute(double num1, double num2) {
		// TODO Auto-generated method stub
		return num1*num2;
	}

}
