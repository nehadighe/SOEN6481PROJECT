import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Button;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
/**
 * 
 * @author Neha
 * Doamin Model - Graphical Interface
 */
public class CalculatorGUI {

	double universalParabolicConstant;
	
	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CalculatorGUI window = new CalculatorGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	UID: 2 Calculation of Universal Parabolic Constant */
	 
	public CalculatorGUI() {
		
		
		CalculateUPC CalculateUPC= new CalculateUPC();
		double sqrt2 = CalculateUPC.sqrt(2);
		double lnVal = (CalculateUPC.Naturallogarithmic(1+sqrt2));
		universalParabolicConstant = (double) lnVal + sqrt2;
		System.out.println(universalParabolicConstant);
		
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 868, 323);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, -11, 832, 284);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		JButton b1=new JButton("1");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"1");
			}
		});
		b1.setBounds(10, 47, 57, 23);
		panel.add(b1);
		
		JButton button = new JButton("2");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"2");
			}
		});
		button.setBounds(75, 47, 54, 23);
		panel.add(button);
		
		JButton button_1 = new JButton("3");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"3");;
			}
		});
		button_1.setBounds(139, 47, 58, 23);
		panel.add(button_1);
		
		JButton button_2 = new JButton("4");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"4");
			}
		});
		button_2.setBounds(10, 81, 57, 23);
		panel.add(button_2);
		
		JButton button_3 = new JButton("5");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"5");
			}
		});
		button_3.setBounds(75, 81, 54, 23);
		panel.add(button_3);
		
		JButton button_4 = new JButton("6");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"6");
			}
		});
		button_4.setBounds(139, 81, 58, 23);
		panel.add(button_4);
		
		JButton button_5 = new JButton("7");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"7");
			}
		});
		button_5.setBounds(10, 115, 57, 23);
		panel.add(button_5);
		
		JButton button_6 = new JButton("8");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"8");
			}
		});
		button_6.setBounds(75, 115, 54, 23);
		panel.add(button_6);
		
		JButton button_7 = new JButton("9");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"9");
			}
		});
		button_7.setBounds(139, 115, 58, 23);
		panel.add(button_7);
		
		JButton button_8 = new JButton("0");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"0");
			}
		});
		button_8.setBounds(75, 149, 54, 23);
		panel.add(button_8);
		
		JButton button_9 = new JButton(".");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+".");
			}
		});
		button_9.setBounds(139, 149, 58, 23);
		panel.add(button_9);
		
		JButton button_10 = new JButton("=");
		button_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Calculator c=new Calculator();
				System.out.println(textField.getText());
				double output=c.ComputeExpression(textField.getText());
				textField.setText(String.valueOf(output));
			}
		});
		button_10.setBounds(271, 134, 54, 36);
		panel.add(button_10);
		
		JButton button_11 = new JButton("+");
		button_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"+");
			}
		});
		button_11.setBounds(207, 47, 54, 23);
		panel.add(button_11);
		
		JButton button_12 = new JButton("-");
		button_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"-");
			}
		});
		button_12.setBounds(207, 81, 54, 23);
		panel.add(button_12);
		
		JButton button_13 = new JButton("*");
		button_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"*");
			}
		});
		button_13.setBounds(207, 115, 54, 23);
		panel.add(button_13);
		
		JButton button_14 = new JButton("/");
		button_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"/");
			}
		});
		button_14.setBounds(207, 149, 54, 23);
		panel.add(button_14);
		
		JButton button_15 = new JButton("UPC");
		button_15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String displayText = String.format("%.3f",universalParabolicConstant );
				
				textField.setText(textField.getText() +displayText);
				//textField.setText("");
			}
		});
		button_15.setBounds(271, 87, 88, 36);
		panel.add(button_15);
		
		JButton button_16 = new JButton("View Application Result");
		button_16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 double area = 3.14 * universalParabolicConstant;
			     double distance = (double)(1.0*1/6)*universalParabolicConstant;
			   
			 	String displayArea = String.format("%.3f", area);
				String displaydistance = String.format("%.3f", distance);
			//	String displayRes = String.format("%.3f", res);
				
				textField_1.setText(displayArea);
				textField_2.setText(displaydistance);

				
				  
				  
			}
		});
		button_16.setBounds(389, 108, 153, 36);
		panel.add(button_16);
		
		JButton button_17 = new JButton("C");
		button_17.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
			}
		});
		button_17.setBounds(10, 149, 57, 23);
		panel.add(button_17);
		
		textField = new JTextField();
		textField.setBounds(10, 11, 153, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setEditable(false);
		textField_1.setColumns(10);
		textField_1.setBounds(20, 197, 153, 20);
		panel.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setEditable(false);
		textField_2.setColumns(10);
		textField_2.setBounds(20, 253, 153, 20);
		panel.add(textField_2);
		
		JLabel lblArea = new JLabel("The Area of the surface generated by revolving x=e^y for y in (-infty,0] \\about the y-axis is given by A = pie * P");
		lblArea.setBounds(20, 176, 640, 17);
		panel.add(lblArea);
		
		JLabel lblTheExpectedDistance = new JLabel("The expected distance from a randomly selected point in the unit square to its center ~d = 1/6 * P ");
		lblTheExpectedDistance.setBounds(21, 228, 603, 14);
		panel.add(lblTheExpectedDistance);
	}
}
