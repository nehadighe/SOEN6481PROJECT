/**
 * 
 * @author Neha
 * Subtraction operator
 */
public class Subtraction implements Operator{

	
	public double execute(double num1, double num2) {
		// TODO Auto-generated method stub
		return num1-num2;
	}

}
