/**
 * 
 * @author Neha
 * UPC Calculation without using LN and SQRT libraries
 */
public class CalculateUPC {
	public  double sqrt(int number) {
		double t;
	 
		double squareRoot = number / 2;
	 
		do {
			t = squareRoot;
			squareRoot = (t + (number / t)) / 2;
		} while ((t - squareRoot) != 0);
	 
		return squareRoot;
	}
	public double Naturallogarithmic(double number)
	{

		double k = 2.7;double n = number;
		double value = 0.0;
		for(double i = 1; i > .001; i /= 10) {
		    while(!(Math.pow(k, value) > n )) {
		        value += i;
		    }
		    value -= i;
		}
		System.out.println(value);
		return value;
		
	}
	
}
